# 战链项目记忆库备份清单 MANIFEST

- 备份时间: 2026-11-21 20:00 +08:00
- 项目: 战链DIY (1a1efe87-33d2-8391-8000-0ea17980fe79)
- 文件总数: 49
- 总大小: 467.7 KB

| # | 路径 | 大小(B) |
|---|---|---|
| 1 | areas/bcd-card-verification.md | 1742 |
| 2 | areas/beta-duel-loadouts.md | 1984 |
| 3 | convention/arena-output-only.md | 1417 |
| 4 | convention/arena-rules-brief.md | 9576 |
| 5 | convention/arena-session-briefing.md | 2766 |
| 6 | convention/diy-card-print-spec.md | 6055 |
| 7 | convention/finisher-switch-protocol.md | 3949 |
| 8 | convention/sim-state-machine.md | 2441 |
| 9 | convention/source-precedence.md | 5745 |
| 10 | convention/supreme-principle.md | 2579 |
| 11 | topic/battlecon-balance-model.md | 3392 |
| 12 | topic/battlecon-bases.md | 17094 |
| 13 | topic/battlecon-glossary.md | 30840 |
| 14 | topic/battlecon-modes.md | 20505 |
| 15 | topic/battlecon-roster-advanced.md | 31624 |
| 16 | topic/battlecon-roster-bcd-t3t5.md | 25933 |
| 17 | topic/battlecon-roster-flight3.md | 9316 |
| 18 | topic/battlecon-roster-other-expansions.md | 29605 |
| 19 | topic/battlecon-roster.md | 16108 |
| 20 | topic/battlecon-rulebook.md | 19145 |
| 21 | topic/diy-chunli.md | 4377 |
| 22 | topic/diy-corner-icons.md | 8501 |
| 23 | topic/diy-defect.md | 8427 |
| 24 | topic/diy-internal-v2.md | 32222 |
| 25 | topic/diy-internal-v3.md | 2755 |
| 26 | topic/diy-internal-v4.md | 2256 |
| 27 | topic/diy-ironclad.md | 8053 |
| 28 | topic/diy-jamie.md | 9332 |
| 29 | topic/diy-luke.md | 7404 |
| 30 | topic/diy-silent.md | 7237 |
| 31 | topic/diy-sts2-defect.md | 7830 |
| 32 | topic/diy-sts2-flavor-final.md | 4253 |
| 33 | topic/diy-sts2-fool.md | 6182 |
| 34 | topic/diy-sts2-ironclad.md | 8178 |
| 35 | topic/diy-sts2-necrobinder.md | 7076 |
| 36 | topic/diy-sts2-regent.md | 6449 |
| 37 | topic/diy-sts2-silent.md | 5633 |
| 38 | topic/diy-sts2-trio-concept.md | 2849 |
| 39 | topic/diy-watcher.md | 7583 |
| 40 | topic/diy-workshop-brief.md | 2042 |
| 41 | topic/diy-zangief.md | 6327 |
| 42 | topic/official-internal-v2.md | 2931 |
| 43 | topic/power-rankings.md | 12238 |
| 44 | topic/roster-bco-online.md | 23451 |
| 45 | topic/sim-engine-results.md | 3951 |
| 46 | topic/sim-report-diy-roundrobin.md | 31309 |
| 47 | topic/sim-report-official-internal.md | 3211 |
| 48 | topic/sts2-flavor-lore.md | 1181 |
| 49 | topic/translation-ambiguities.md | 3865 |

## 说明
- 按原结构镜像: areas/ convention/ topic/ 三层目录与记忆库一致
- 每个 .md 文件 = 记忆库中同名文件的完整 YAML 头 + 正文
- 备份为时点快照;记忆库被多会话并行更新,恢复时以库内版本为准,本备份用于灾难恢复/离线查阅
- 恢复方式: 将各文件内容贴回对应会话由 AI 重建,或直接作为只读参考